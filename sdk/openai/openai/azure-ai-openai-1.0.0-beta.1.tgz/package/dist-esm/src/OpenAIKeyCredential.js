/**
 * The OpenAIKeyCredential class represents an OpenAI key
 * and is used to authenticate into an OpenAI client for
 * an OpenAI endpoint.
 */
export class OpenAIKeyCredential {
    /**
     * Create an instance of an AzureKeyCredential for use
     * with a service client.
     *
     * @param key - The initial value of the key to use in authentication
     */
    constructor(key) {
        if (!key) {
            throw new Error("key must be a non-empty string");
        }
        this._key = createKey(key);
    }
    /**
     * The value of the key to be used in authentication
     */
    get key() {
        return this._key;
    }
    /**
     * Change the value of the key.
     *
     * Updates will take effect upon the next request after
     * updating the key value.
     *
     * @param newKey - The new key value to be used
     */
    /**
     * Change the value of the key.
     *
     * Updates will take effect upon the next request after
     * updating the key value.
     *
     * @param newKey - The new key value to be used
     */
    update(newKey) {
        this._key = createKey(newKey);
    }
}
function createKey(key) {
    return key.startsWith("Bearer ") ? key : `Bearer ${key}`;
}
//# sourceMappingURL=OpenAIKeyCredential.js.map