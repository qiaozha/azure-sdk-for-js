// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { __rest } from "tslib";
import { isTokenCredential } from "@azure/core-auth";
import { createOpenAI, getChatCompletions, getCompletions, getEmbeddings, } from "./api/index.js";
import { getSSEs } from "./api/sse.js";
import { getChatCompletionsResponse, getChatCompletionsResult, getCompletionsResponse, getCompletionsResult, } from "./api/operations.js";
export class OpenAIClient {
    constructor(endpointOrOpenAiKey, credOrOptions = {}, options = {}) {
        var _a, _b;
        this._isAzure = false;
        let opts;
        let endpoint;
        let cred;
        if (isCred(credOrOptions)) {
            endpoint = endpointOrOpenAiKey;
            cred = credOrOptions;
            opts = options;
            this._isAzure = true;
        }
        else {
            endpoint = createOpenAIEndpoint(1);
            cred = endpointOrOpenAiKey;
            const { credentials } = credOrOptions, restOpts = __rest(credOrOptions, ["credentials"]);
            opts = Object.assign({ credentials: {
                    apiKeyHeaderName: (_a = credentials === null || credentials === void 0 ? void 0 : credentials.apiKeyHeaderName) !== null && _a !== void 0 ? _a : "Authorization",
                    scopes: credentials === null || credentials === void 0 ? void 0 : credentials.scopes,
                } }, restOpts);
        }
        this._client = createOpenAI(endpoint, cred, Object.assign(Object.assign({}, opts), (this._isAzure
            ? {}
            : {
                additionalPolicies: [
                    ...((_b = opts.additionalPolicies) !== null && _b !== void 0 ? _b : []),
                    {
                        position: "perCall",
                        policy: {
                            name: "openAiEndpoint",
                            sendRequest: (request, next) => {
                                const obj = new URL(request.url);
                                const parts = obj.pathname.split("/");
                                obj.pathname = `/${parts[1]}/${parts.slice(5).join("/")}`;
                                obj.searchParams.delete("api-version");
                                request.url = obj.toString();
                                return next(request);
                            },
                        },
                    },
                ],
            })));
    }
    getEmbeddings(deploymentOrModelName, input, options = { requestOptions: {} }) {
        this.setModel(deploymentOrModelName, options);
        return getEmbeddings(this._client, input, deploymentOrModelName, options);
    }
    getChatCompletions(deploymentOrModelName, messages, options = { requestOptions: {} }) {
        this.setModel(deploymentOrModelName, options);
        return getChatCompletions(this._client, messages, deploymentOrModelName, options);
    }
    getCompletions(deploymentOrModelName, promptOrOptions, options = { requestOptions: {} }) {
        this.setModel(deploymentOrModelName, options);
        return getCompletions(this._client, deploymentOrModelName, promptOrOptions, options);
    }
    getCompletionsStreaming(deploymentOrModelName, promptOrOptions, options = { requestOptions: {} }) {
        this.setModel(deploymentOrModelName, options);
        const opts = typeof promptOrOptions === "object" && !Array.isArray(promptOrOptions)
            ? promptOrOptions
            : Object.assign(Object.assign({}, options), { prompt: promptOrOptions });
        opts.stream = true;
        const response = getCompletionsResponse(this._client, deploymentOrModelName, opts);
        return getSSEs(response, getCompletionsResult);
    }
    getChatCompletionsStreaming(deploymentOrModelName, messages, options = { requestOptions: {} }) {
        this.setModel(deploymentOrModelName, options);
        options.stream = true;
        const response = getChatCompletionsResponse(this._client, messages, deploymentOrModelName, options);
        return getSSEs(response, getChatCompletionsResult);
    }
    setModel(model, options) {
        if (!this._isAzure) {
            options.model = model;
        }
    }
}
function createOpenAIEndpoint(version) {
    return `https://api.openai.com/v${version}`;
}
function isCred(cred) {
    return isTokenCredential(cred) || cred.key !== undefined;
}
//# sourceMappingURL=OpenAIClient.js.map