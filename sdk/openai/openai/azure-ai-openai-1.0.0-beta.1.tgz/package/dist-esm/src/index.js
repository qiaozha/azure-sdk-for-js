// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export { OpenAIClient, } from "./OpenAIClient.js";
export { getChatCompletions, getCompletions, getEmbeddings, } from "./api/operations.js";
export { OpenAIKeyCredential } from "./OpenAIKeyCredential.js";
//# sourceMappingURL=index.js.map