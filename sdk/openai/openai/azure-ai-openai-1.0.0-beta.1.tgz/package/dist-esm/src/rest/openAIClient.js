// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { getClient } from "@azure-rest/core-client";
/**
 * Initialize a new instance of `OpenAIContext`
 * @param endpoint type: string, Supported Cognitive Services endpoints (protocol and hostname, for example:
 * https://westus.api.cognitive.microsoft.com).
 * @param credentials type: TokenCredential|KeyCredential, uniquely identify client credential
 * @param options type: ClientOptions, the parameter for all optional parameters
 */
export default function createClient(endpoint, credentials, options = {}) {
    var _a, _b;
    const baseUrl = (_a = options.baseUrl) !== null && _a !== void 0 ? _a : `${endpoint}/openai`;
    options.apiVersion = (_b = options.apiVersion) !== null && _b !== void 0 ? _b : "2023-03-15-preview";
    options = Object.assign({ credentials: {
            scopes: ["https://cognitiveservices.azure.com/.default"],
            apiKeyHeaderName: "api-key",
        } }, options);
    const userAgentInfo = `azsdk-js-ai-openai-rest/1.0.0-beta.1`;
    const userAgentPrefix = options.userAgentOptions && options.userAgentOptions.userAgentPrefix
        ? `${options.userAgentOptions.userAgentPrefix} ${userAgentInfo}`
        : `${userAgentInfo}`;
    options = Object.assign(Object.assign({}, options), { userAgentOptions: {
            userAgentPrefix,
        } });
    const client = getClient(baseUrl, credentials, options);
    return client;
}
//# sourceMappingURL=openAIClient.js.map