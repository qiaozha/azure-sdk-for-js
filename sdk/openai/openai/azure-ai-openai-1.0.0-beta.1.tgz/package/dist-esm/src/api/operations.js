// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { isUnexpected, } from "../rest/index.js";
/** Return the embeddings for a given prompt. */
export async function getEmbeddings(context, input, deploymentId, options = { requestOptions: {} }) {
    var _a, _b, _c;
    const result = await context.path("/deployments/{deploymentId}/embeddings", deploymentId).post({
        contentType: (_a = options.content_type) !== null && _a !== void 0 ? _a : "application/json",
        headers: Object.assign({ Accept: "application/json" }, (_b = options.requestOptions) === null || _b === void 0 ? void 0 : _b.headers),
        body: Object.assign(Object.assign(Object.assign({}, (options.user && { user: options.user })), (options.model && { model: options.model })), { input: input }),
    });
    if (isUnexpected(result)) {
        throw result.body;
    }
    return {
        data: ((_c = result.body["data"]) !== null && _c !== void 0 ? _c : []).map((p) => ({
            embedding: p["embedding"],
            index: p["index"],
        })),
        usage: {
            promptTokens: result.body.usage["prompt_tokens"],
            totalTokens: result.body.usage["total_tokens"],
        },
    };
}
/**
 * Gets chat completions for the provided chat messages.
 * Completions support a wide variety of tasks and generate text that continues from or "completes"
 * provided prompt data.
 */
export async function getChatCompletions(context, messages, deploymentId, options = { requestOptions: {} }) {
    var _a, _b, _c;
    const result = await context
        .path("/deployments/{deploymentId}/chat/completions", deploymentId)
        .post({
        contentType: (_a = options.content_type) !== null && _a !== void 0 ? _a : "application/json",
        headers: Object.assign({ Accept: "application/json" }, (_b = options.requestOptions) === null || _b === void 0 ? void 0 : _b.headers),
        body: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({ messages: messages }, (options.maxTokens && { max_tokens: options.maxTokens })), (options.temperature && { temperature: options.temperature })), (options.topP && { top_p: options.topP })), (options.logitBias && { logit_bias: options.logitBias })), (options.user && { user: options.user })), (options.n && { n: options.n })), (options.stop && { stop: options.stop })), (options.presencePenalty && {
            presence_penalty: options.presencePenalty,
        })), (options.frequencyPenalty && {
            frequency_penalty: options.frequencyPenalty,
        })), (options.stream && { stream: options.stream })), (options.model && { model: options.model })),
    });
    if (isUnexpected(result)) {
        throw result.body;
    }
    return {
        id: result.body["id"],
        created: result.body["created"],
        choices: ((_c = result.body["choices"]) !== null && _c !== void 0 ? _c : []).map((p) => {
            var _a, _b, _c, _d;
            return ({
                message: !p.message
                    ? undefined
                    : { role: (_a = p.message) === null || _a === void 0 ? void 0 : _a["role"], content: (_b = p.message) === null || _b === void 0 ? void 0 : _b["content"] },
                index: p["index"],
                finishReason: p["finish_reason"],
                delta: !p.delta ? undefined : { role: (_c = p.delta) === null || _c === void 0 ? void 0 : _c["role"], content: (_d = p.delta) === null || _d === void 0 ? void 0 : _d["content"] },
            });
        }),
        usage: {
            completionTokens: result.body.usage["completion_tokens"],
            promptTokens: result.body.usage["prompt_tokens"],
            totalTokens: result.body.usage["total_tokens"],
        },
    };
}
export async function getCompletions(context, deploymentId, promptOrOptions, options = { requestOptions: {} }) {
    return _getCompletions(context, deploymentId, typeof promptOrOptions === "object" && !Array.isArray(promptOrOptions)
        ? promptOrOptions
        : Object.assign(Object.assign({}, options), { prompt: promptOrOptions }));
}
export function getCompletionsResponse(context, deploymentId, options = { requestOptions: {} }) {
    var _a, _b;
    return context.path("/deployments/{deploymentId}/completions", deploymentId).post({
        contentType: (_a = options.content_type) !== null && _a !== void 0 ? _a : "application/json",
        headers: Object.assign({ Accept: "application/json" }, (_b = options.requestOptions) === null || _b === void 0 ? void 0 : _b.headers),
        body: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, (options.prompt && { prompt: options.prompt })), (options.maxTokens && { max_tokens: options.maxTokens })), (options.temperature && { temperature: options.temperature })), (options.topP && { top_p: options.topP })), (options.logitBias && { logit_bias: options.logitBias })), (options.user && { user: options.user })), (options.n && { n: options.n })), (options.logprobs && { logprobs: options.logprobs })), (options.echo && { echo: options.echo })), (options.stop && { stop: options.stop })), (options.presencePenalty && {
            presence_penalty: options.presencePenalty,
        })), (options.frequencyPenalty && {
            frequency_penalty: options.frequencyPenalty,
        })), (options.bestOf && { best_of: options.bestOf })), (options.stream && { stream: options.stream })), (options.model && { model: options.model })),
    });
}
export function getCompletionsResult(body) {
    var _a;
    return {
        id: body["id"],
        created: body["created"],
        choices: ((_a = body["choices"]) !== null && _a !== void 0 ? _a : []).map((p) => {
            var _a, _b, _c, _d;
            return ({
                text: p["text"],
                index: p["index"],
                logprobs: !p.logprobs
                    ? undefined
                    : {
                        tokens: (_a = p.logprobs) === null || _a === void 0 ? void 0 : _a["tokens"],
                        tokenLogprobs: (_b = p.logprobs) === null || _b === void 0 ? void 0 : _b["token_logprobs"],
                        topLogprobs: (_c = p.logprobs) === null || _c === void 0 ? void 0 : _c["top_logprobs"],
                        textOffset: (_d = p.logprobs) === null || _d === void 0 ? void 0 : _d["text_offset"],
                    },
                finishReason: p["finish_reason"],
            });
        }),
    };
}
export function getChatCompletionsResponse(context, messages, deploymentId, options = { requestOptions: {} }) {
    var _a, _b;
    return context.path("/deployments/{deploymentId}/chat/completions", deploymentId).post({
        contentType: (_a = options.content_type) !== null && _a !== void 0 ? _a : "application/json",
        headers: Object.assign({ Accept: "application/json" }, (_b = options.requestOptions) === null || _b === void 0 ? void 0 : _b.headers),
        body: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({ messages: messages }, (options.maxTokens && { max_tokens: options.maxTokens })), (options.temperature && { temperature: options.temperature })), (options.topP && { top_p: options.topP })), (options.logitBias && { logit_bias: options.logitBias })), (options.user && { user: options.user })), (options.n && { n: options.n })), (options.stop && { stop: options.stop })), (options.presencePenalty && {
            presence_penalty: options.presencePenalty,
        })), (options.frequencyPenalty && {
            frequency_penalty: options.frequencyPenalty,
        })), (options.stream && { stream: options.stream })), (options.model && { model: options.model })),
    });
}
export function getChatCompletionsResult(body) {
    var _a;
    return {
        id: body["id"],
        created: body["created"],
        choices: ((_a = body["choices"]) !== null && _a !== void 0 ? _a : []).map((p) => {
            var _a, _b, _c, _d;
            return ({
                message: !p.message
                    ? undefined
                    : { role: (_a = p.message) === null || _a === void 0 ? void 0 : _a["role"], content: (_b = p.message) === null || _b === void 0 ? void 0 : _b["content"] },
                index: p["index"],
                finishReason: p["finish_reason"],
                delta: !p.delta ? undefined : { role: (_c = p.delta) === null || _c === void 0 ? void 0 : _c["role"], content: (_d = p.delta) === null || _d === void 0 ? void 0 : _d["content"] },
            });
        }),
    };
}
/**
 * Gets completions for the provided input prompts.
 * Completions support a wide variety of tasks and generate text that continues from or "completes"
 * provided prompt data.
 */
async function _getCompletions(context, deploymentId, options = { requestOptions: {} }) {
    var _a, _b, _c;
    const result = await context.path("/deployments/{deploymentId}/completions", deploymentId).post({
        contentType: (_a = options.content_type) !== null && _a !== void 0 ? _a : "application/json",
        headers: Object.assign({ Accept: "application/json" }, (_b = options.requestOptions) === null || _b === void 0 ? void 0 : _b.headers),
        body: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, (options.prompt && { prompt: options.prompt })), (options.maxTokens && { max_tokens: options.maxTokens })), (options.temperature && { temperature: options.temperature })), (options.topP && { top_p: options.topP })), (options.logitBias && { logit_bias: options.logitBias })), (options.user && { user: options.user })), (options.n && { n: options.n })), (options.logprobs && { logprobs: options.logprobs })), (options.echo && { echo: options.echo })), (options.stop && { stop: options.stop })), (options.presencePenalty && {
            presence_penalty: options.presencePenalty,
        })), (options.frequencyPenalty && {
            frequency_penalty: options.frequencyPenalty,
        })), (options.bestOf && { best_of: options.bestOf })), (options.stream && { stream: options.stream })), (options.model && { model: options.model })),
    });
    if (isUnexpected(result)) {
        throw result.body;
    }
    return {
        id: result.body["id"],
        created: result.body["created"],
        choices: ((_c = result.body["choices"]) !== null && _c !== void 0 ? _c : []).map((p) => {
            var _a, _b, _c, _d;
            return ({
                text: p["text"],
                index: p["index"],
                logprobs: !p.logprobs
                    ? undefined
                    : {
                        tokens: (_a = p.logprobs) === null || _a === void 0 ? void 0 : _a["tokens"],
                        tokenLogprobs: (_b = p.logprobs) === null || _b === void 0 ? void 0 : _b["token_logprobs"],
                        topLogprobs: (_c = p.logprobs) === null || _c === void 0 ? void 0 : _c["top_logprobs"],
                        textOffset: (_d = p.logprobs) === null || _d === void 0 ? void 0 : _d["text_offset"],
                    },
                finishReason: p["finish_reason"],
            });
        }),
        usage: {
            completionTokens: result.body.usage["completion_tokens"],
            promptTokens: result.body.usage["prompt_tokens"],
            totalTokens: result.body.usage["total_tokens"],
        },
    };
}
//# sourceMappingURL=operations.js.map