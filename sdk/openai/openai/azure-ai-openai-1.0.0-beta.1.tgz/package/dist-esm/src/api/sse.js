// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { __asyncDelegator, __asyncGenerator, __asyncValues, __await } from "tslib";
import { getStream } from "./getStream.js";
export async function getSSEs(response, toEvent) {
    const stream = getStream(response);
    let prevLineIfIncomplete = "";
    let started = false;
    return streamToEvents(stream, (chunk) => {
        if (!chunk.startsWith("data: ") && !started) {
            throw new Error(chunk);
        }
        started = true;
        return chunk.split("\n\n").reduce((events, str) => {
            let event;
            if (str.startsWith("data: ")) {
                str = str.slice(6);
            }
            if (["", "[DONE]", "[DONE]\n"].includes(str)) {
                return events;
            }
            if (prevLineIfIncomplete) {
                event = JSON.parse(prevLineIfIncomplete + str);
                prevLineIfIncomplete = "";
            }
            else {
                try {
                    event = JSON.parse(str);
                }
                catch (e) {
                    prevLineIfIncomplete = str;
                }
            }
            return event !== undefined ? [...events, toEvent(event)] : events;
        }, []);
    });
}
function streamToEvents(stream, processChunk) {
    return __asyncGenerator(this, arguments, function* streamToEvents_1() {
        var _a, e_1, _b, _c;
        try {
            for (var _d = true, stream_1 = __asyncValues(stream), stream_1_1; stream_1_1 = yield __await(stream_1.next()), _a = stream_1_1.done, !_a;) {
                _c = stream_1_1.value;
                _d = false;
                try {
                    const chunk = _c;
                    yield __await(yield* __asyncDelegator(__asyncValues(processChunk(chunk))));
                }
                finally {
                    _d = true;
                }
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (!_d && !_a && (_b = stream_1.return)) yield __await(_b.call(stream_1));
            }
            finally { if (e_1) throw e_1.error; }
        }
    });
}
//# sourceMappingURL=sse.js.map