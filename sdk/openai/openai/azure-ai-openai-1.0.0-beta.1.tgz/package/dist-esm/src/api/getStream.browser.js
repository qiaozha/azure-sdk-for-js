// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { __asyncGenerator, __await } from "tslib";
export function getStream(response) {
    return __asyncGenerator(this, arguments, function* getStream_1() {
        const stream = (yield __await(response.asBrowserStream())).body;
        if (!stream)
            throw new Error("No stream found in response");
        const encoder = new TextDecoder();
        // The cast to any is needed because the ReadableStream type in the browser is shimmed and dom is not imported.
        const reader = stream.getReader();
        while (true) {
            const { value, done } = yield __await(reader.read());
            if (done) {
                break;
            }
            yield yield __await(encoder.decode(value));
        }
    });
}
//# sourceMappingURL=getStream.browser.js.map