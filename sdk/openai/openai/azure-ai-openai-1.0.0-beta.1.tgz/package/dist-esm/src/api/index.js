// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export { createOpenAI } from "./OpenAIContext.js";
export { getChatCompletions, getCompletions, getEmbeddings, } from "./operations.js";
//# sourceMappingURL=index.js.map