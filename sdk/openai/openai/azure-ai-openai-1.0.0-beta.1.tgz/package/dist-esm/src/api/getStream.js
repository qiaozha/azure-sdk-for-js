// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { __asyncGenerator, __asyncValues, __await } from "tslib";
export function getStream(response) {
    return __asyncGenerator(this, arguments, function* getStream_1() {
        var _a, e_1, _b, _c;
        const stream = (yield __await(response.asNodeStream())).body;
        if (!stream)
            throw new Error("No stream found in response. Did you enable the stream option?");
        try {
            for (var _d = true, stream_1 = __asyncValues(stream), stream_1_1; stream_1_1 = yield __await(stream_1.next()), _a = stream_1_1.done, !_a;) {
                _c = stream_1_1.value;
                _d = false;
                try {
                    const chunk = _c;
                    yield yield __await(chunk.toString());
                }
                finally {
                    _d = true;
                }
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (!_d && !_a && (_b = stream_1.return)) yield __await(_b.call(stream_1));
            }
            finally { if (e_1) throw e_1.error; }
        }
    });
}
//# sourceMappingURL=getStream.js.map