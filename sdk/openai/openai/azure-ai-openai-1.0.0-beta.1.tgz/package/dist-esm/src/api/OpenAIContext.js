// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import getClient from "../rest/index.js";
/** Azure OpenAI APIs for completions and search */
export function createOpenAI(endpoint, credential, options = {}) {
    const baseUrl = endpoint;
    const clientContext = getClient(baseUrl, credential, options);
    return clientContext;
}
//# sourceMappingURL=OpenAIContext.js.map