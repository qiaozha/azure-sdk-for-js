import { Client } from '@azure-rest/core-client';
import { ClientOptions as ClientOptions_2 } from '@azure-rest/core-client';
import { ErrorResponse } from '@azure-rest/core-client';
import { HttpResponse } from '@azure-rest/core-client';
import { KeyCredential } from '@azure/core-auth';
import { RawHttpHeaders } from '@azure/core-rest-pipeline';
import { RawHttpHeadersInput } from '@azure/core-rest-pipeline';
import { RequestParameters } from '@azure-rest/core-client';
import { StreamableMethod } from '@azure-rest/core-client';
import { TokenCredential } from '@azure/core-auth';

/**
 * The representation of a single prompt completion as part of an overall chat completions request.
 * Generally, `n` choices are generated per provided prompt with a default value of 1.
 * Token limits and other settings may limit the number of choices generated.
 */
export declare interface ChatChoice {
    /** The chat message for a given chat completions prompt. */
    message?: ChatMessage;
    /** The ordered index associated with this chat completions choice. */
    index: number;
    /** The reason that this chat completions choice completed its generated. */
    finishReason: CompletionsFinishReason;
    /** The delta message content for a streaming response. */
    delta?: ChatMessage;
}

/**
 * The representation of a single prompt completion as part of an overall chat completions request.
 * Generally, `n` choices are generated per provided prompt with a default value of 1.
 * Token limits and other settings may limit the number of choices generated.
 */
declare interface ChatChoiceOutput {
    /** The chat message for a given chat completions prompt. */
    message?: ChatMessageOutput;
    /** The ordered index associated with this chat completions choice. */
    index: number;
    /**
     * The reason that this chat completions choice completed its generated.
     *
     * Possible values: none, stopped, tokenLimitReached, contentFiltered
     */
    finish_reason: string;
    /** The delta message content for a streaming response. */
    delta?: ChatMessageOutput;
}

/** */
export declare interface ChatCompletionsOptions {
    /**
     * The collection of context messages associated with this chat completions request.
     * Typical usage begins with a chat message for the System role that provides instructions for
     * the behavior of the assistant, followed by alternating messages between the User and
     * Assistant roles.
     */
    messages: ChatMessage[];
    /** The maximum number of tokens to generate. */
    maxTokens?: number;
    /**
     * The sampling temperature to use that controls the apparent creativity of generated completions.
     * Higher values will make output more random while lower values will make results more focused
     * and deterministic.
     * It is not recommended to modify temperature and top_p for the same completions request as the
     * interaction of these two settings is difficult to predict.
     */
    temperature?: number;
    /**
     * An alternative to sampling with temperature called nucleus sampling. This value causes the
     * model to consider the results of tokens with the provided probability mass. As an example, a
     * value of 0.15 will cause only the tokens comprising the top 15% of probability mass to be
     * considered.
     * It is not recommended to modify temperature and top_p for the same completions request as the
     * interaction of these two settings is difficult to predict.
     */
    topP?: number;
    /**
     * A map between GPT token IDs and bias scores that influences the probability of specific tokens
     * appearing in a completions response. Token IDs are computed via external tokenizer tools, while
     * bias scores reside in the range of -100 to 100 with minimum and maximum values corresponding to
     * a full ban or exclusive selection of a token, respectively. The exact behavior of a given bias
     * score varies by model.
     */
    logitBias?: Record<string, number>;
    /**
     * An identifier for the caller or end user of the operation. This may be used for tracking
     * or rate-limiting purposes.
     */
    user?: string;
    /**
     * The number of completions choices that should be generated per provided prompt as part of an
     * overall completions response.
     * Because this setting can generate many completions, it may quickly consume your token quota.
     * Use carefully and ensure reasonable settings for max_tokens and stop.
     */
    n?: number;
    /** A collection of textual sequences that will end completions generation. */
    stop?: string[];
    /**
     * A value that influences the probability of generated tokens appearing based on their existing
     * presence in generated text.
     * Positive values will make tokens less likely to appear when they already exist and increase the
     * model's likelihood to output new topics.
     */
    presencePenalty?: number;
    /**
     * A value that influences the probability of generated tokens appearing based on their cumulative
     * frequency in generated text.
     * Positive values will make tokens less likely to appear as their frequency increases and
     * decrease the likelihood of the model repeating the same statements verbatim.
     */
    frequencyPenalty?: number;
    /** A value indicating whether chat completions should be streamed for this request. */
    stream?: boolean;
    /**
     * The model name to provide as part of this completions request.
     * Not applicable to Azure OpenAI, where deployment information should be included in the Azure
     * resource URI that's connected to.
     */
    model?: string;
}

/**
 * The configuration information for a chat completions request.
 * Completions support a wide variety of tasks and generate text that continues from or "completes"
 * provided prompt data.
 */
declare interface ChatCompletionsOptions_2 {
    /**
     * The collection of context messages associated with this chat completions request.
     * Typical usage begins with a chat message for the System role that provides instructions for
     * the behavior of the assistant, followed by alternating messages between the User and
     * Assistant roles.
     */
    messages: Array<ChatMessage_2>;
    /** The maximum number of tokens to generate. */
    max_tokens?: number;
    /**
     * The sampling temperature to use that controls the apparent creativity of generated completions.
     * Higher values will make output more random while lower values will make results more focused
     * and deterministic.
     * It is not recommended to modify temperature and top_p for the same completions request as the
     * interaction of these two settings is difficult to predict.
     */
    temperature?: number;
    /**
     * An alternative to sampling with temperature called nucleus sampling. This value causes the
     * model to consider the results of tokens with the provided probability mass. As an example, a
     * value of 0.15 will cause only the tokens comprising the top 15% of probability mass to be
     * considered.
     * It is not recommended to modify temperature and top_p for the same completions request as the
     * interaction of these two settings is difficult to predict.
     */
    top_p?: number;
    /**
     * A map between GPT token IDs and bias scores that influences the probability of specific tokens
     * appearing in a completions response. Token IDs are computed via external tokenizer tools, while
     * bias scores reside in the range of -100 to 100 with minimum and maximum values corresponding to
     * a full ban or exclusive selection of a token, respectively. The exact behavior of a given bias
     * score varies by model.
     */
    logit_bias?: Record<string, number>;
    /**
     * An identifier for the caller or end user of the operation. This may be used for tracking
     * or rate-limiting purposes.
     */
    user?: string;
    /**
     * The number of completions choices that should be generated per provided prompt as part of an
     * overall completions response.
     * Because this setting can generate many completions, it may quickly consume your token quota.
     * Use carefully and ensure reasonable settings for max_tokens and stop.
     */
    n?: number;
    /** A collection of textual sequences that will end completions generation. */
    stop?: string[];
    /**
     * A value that influences the probability of generated tokens appearing based on their existing
     * presence in generated text.
     * Positive values will make tokens less likely to appear when they already exist and increase the
     * model's likelihood to output new topics.
     */
    presence_penalty?: number;
    /**
     * A value that influences the probability of generated tokens appearing based on their cumulative
     * frequency in generated text.
     * Positive values will make tokens less likely to appear as their frequency increases and
     * decrease the likelihood of the model repeating the same statements verbatim.
     */
    frequency_penalty?: number;
    /** A value indicating whether chat completions should be streamed for this request. */
    stream?: boolean;
    /**
     * The model name to provide as part of this completions request.
     * Not applicable to Azure OpenAI, where deployment information should be included in the Azure
     * resource URI that's connected to.
     */
    model?: string;
}

/**
 * Representation of the response data from a chat completions request.
 * Completions support a wide variety of tasks and generate text that continues from or "completes"
 * provided prompt data.
 */
declare interface ChatCompletionsOutput {
    /** A unique identifier associated with this chat completions response. */
    id: string;
    /**
     * The first timestamp associated with generation activity for this completions response,
     * represented as seconds since the beginning of the Unix epoch of 00:00 on 1 Jan 1970.
     */
    created: number;
    /**
     * The collection of completions choices associated with this completions response.
     * Generally, `n` choices are generated per provided prompt with a default value of 1.
     * Token limits and other settings may limit the number of choices generated.
     */
    choices?: Array<ChatChoiceOutput>;
    /** Usage information for tokens processed and generated as part of this completions operation. */
    usage: CompletionsUsageOutput;
}

export declare type ChatCompletionsStream = AsyncIterable<Omit<DeploymentChatCompletionsOptionsChatCompletions, "usage">>;

/** A single, role-attributed message within a chat completion interaction. */
export declare interface ChatMessage {
    /** The role associated with this message payload. */
    role: ChatRole;
    /** The text associated with this message payload. */
    content?: string;
}

/** A single, role-attributed message within a chat completion interaction. */
declare interface ChatMessage_2 {
    /**
     * The role associated with this message payload.
     *
     * Possible values: system, assistant, user
     */
    role: string;
    /** The text associated with this message payload. */
    content?: string;
}

/** A single, role-attributed message within a chat completion interaction. */
declare interface ChatMessageOutput {
    /**
     * The role associated with this message payload.
     *
     * Possible values: system, assistant, user
     */
    role: string;
    /** The text associated with this message payload. */
    content?: string;
}

/** A description of the intended purpose of a message within a chat completions interaction. */
/** "system", "assistant", "user" */
export declare type ChatRole = string;

/**
 * The representation of a single prompt completion as part of an overall completions request.
 * Generally, `n` choices are generated per provided prompt with a default value of 1.
 * Token limits and other settings may limit the number of choices generated.
 */
export declare interface Choice {
    /** The generated text for a given completions prompt. */
    text: string;
    /** The ordered index associated with this completions choice. */
    index: number;
    /** The log probabilities model for tokens associated with this completions choice. */
    logprobs?: CompletionsLogProbabilityModel;
    /** Reason for finishing */
    finishReason: CompletionsFinishReason;
}

/**
 * The representation of a single prompt completion as part of an overall completions request.
 * Generally, `n` choices are generated per provided prompt with a default value of 1.
 * Token limits and other settings may limit the number of choices generated.
 */
declare interface ChoiceOutput {
    /** The generated text for a given completions prompt. */
    text: string;
    /** The ordered index associated with this completions choice. */
    index: number;
    /** The log probabilities model for tokens associated with this completions choice. */
    logprobs?: CompletionsLogProbabilityModelOutput;
    /**
     * Reason for finishing
     *
     * Possible values: none, stopped, tokenLimitReached, contentFiltered
     */
    finish_reason: string;
}

export declare interface ClientOptions extends ClientOptions_2 {
}

/** Representation of the manner in which a completions response concluded. */
/** "none", "stopped", "tokenLimitReached", "contentFiltered" */
export declare type CompletionsFinishReason = string;

/** Representation of a log probabilities model for a completions generation. */
export declare interface CompletionsLogProbabilityModel {
    /** The textual forms of tokens evaluated in this probability model. */
    tokens?: string[];
    /** A collection of log probability values for the tokens in this completions data. */
    tokenLogprobs?: number[];
    /** A mapping of tokens to maximum log probability values in this completions data. */
    topLogprobs?: Record<string, number>[];
    /** The text offsets associated with tokens in this completions data. */
    textOffset?: number[];
}

/** Representation of a log probabilities model for a completions generation. */
declare interface CompletionsLogProbabilityModelOutput {
    /** The textual forms of tokens evaluated in this probability model. */
    tokens?: string[];
    /** A collection of log probability values for the tokens in this completions data. */
    token_logprobs?: number[];
    /** A mapping of tokens to maximum log probability values in this completions data. */
    top_logprobs?: Record<string, number>[];
    /** The text offsets associated with tokens in this completions data. */
    text_offset?: number[];
}

/** */
export declare interface CompletionsOptions {
    /**
     * The prompts to generate completions from. Defaults to a single prompt of <|endoftext|> if not
     * otherwise specified.
     */
    prompt?: string[] | string;
    /** The maximum number of tokens to generate. */
    maxTokens?: number;
    /**
     * The sampling temperature to use that controls the apparent creativity of generated completions.
     * Higher values will make output more random while lower values will make results more focused
     * and deterministic.
     * It is not recommended to modify temperature and top_p for the same completions request as the
     * interaction of these two settings is difficult to predict.
     */
    temperature?: number;
    /**
     * An alternative to sampling with temperature called nucleus sampling. This value causes the
     * model to consider the results of tokens with the provided probability mass. As an example, a
     * value of 0.15 will cause only the tokens comprising the top 15% of probability mass to be
     * considered.
     * It is not recommended to modify temperature and top_p for the same completions request as the
     * interaction of these two settings is difficult to predict.
     */
    topP?: number;
    /**
     * A map between GPT token IDs and bias scores that influences the probability of specific tokens
     * appearing in a completions response. Token IDs are computed via external tokenizer tools, while
     * bias scores reside in the range of -100 to 100 with minimum and maximum values corresponding to
     * a full ban or exclusive selection of a token, respectively. The exact behavior of a given bias
     * score varies by model.
     */
    logitBias?: Record<string, number>;
    /**
     * An identifier for the caller or end user of the operation. This may be used for tracking
     * or rate-limiting purposes.
     */
    user?: string;
    /**
     * The number of completions choices that should be generated per provided prompt as part of an
     * overall completions response.
     * Because this setting can generate many completions, it may quickly consume your token quota.
     * Use carefully and ensure reasonable settings for max_tokens and stop.
     */
    n?: number;
    /**
     * A value that controls the emission of log probabilities for the provided number of most likely
     * tokens within a completions response.
     */
    logprobs?: number;
    /**
     * A value specifying whether completions responses should include input prompts as prefixes to
     * their generated output.
     */
    echo?: boolean;
    /** A collection of textual sequences that will end completions generation. */
    stop?: string[];
    /**
     * A value that influences the probability of generated tokens appearing based on their existing
     * presence in generated text.
     * Positive values will make tokens less likely to appear when they already exist and increase the
     * model's likelihood to output new topics.
     */
    presencePenalty?: number;
    /**
     * A value that influences the probability of generated tokens appearing based on their cumulative
     * frequency in generated text.
     * Positive values will make tokens less likely to appear as their frequency increases and
     * decrease the likelihood of the model repeating the same statements verbatim.
     */
    frequencyPenalty?: number;
    /**
     * A value that controls how many completions will be internally generated prior to response
     * formulation.
     * When used together with n, best_of controls the number of candidate completions and must be
     * greater than n.
     * Because this setting can generate many completions, it may quickly consume your token quota.
     * Use carefully and ensure reasonable settings for max_tokens and stop.
     */
    bestOf?: number;
    /** A value indicating whether chat completions should be streamed for this request. */
    stream?: boolean;
    /**
     * The model name to provide as part of this completions request.
     * Not applicable to Azure OpenAI, where deployment information should be included in the Azure
     * resource URI that's connected to.
     */
    model?: string;
}

/**
 * The configuration information for a completions request.
 * Completions support a wide variety of tasks and generate text that continues from or "completes"
 * provided prompt data.
 */
declare interface CompletionsOptions_2 {
    /**
     * The prompts to generate completions from. Defaults to a single prompt of <|endoftext|> if not
     * otherwise specified.
     */
    prompt?: string[] | string;
    /** The maximum number of tokens to generate. */
    max_tokens?: number;
    /**
     * The sampling temperature to use that controls the apparent creativity of generated completions.
     * Higher values will make output more random while lower values will make results more focused
     * and deterministic.
     * It is not recommended to modify temperature and top_p for the same completions request as the
     * interaction of these two settings is difficult to predict.
     */
    temperature?: number;
    /**
     * An alternative to sampling with temperature called nucleus sampling. This value causes the
     * model to consider the results of tokens with the provided probability mass. As an example, a
     * value of 0.15 will cause only the tokens comprising the top 15% of probability mass to be
     * considered.
     * It is not recommended to modify temperature and top_p for the same completions request as the
     * interaction of these two settings is difficult to predict.
     */
    top_p?: number;
    /**
     * A map between GPT token IDs and bias scores that influences the probability of specific tokens
     * appearing in a completions response. Token IDs are computed via external tokenizer tools, while
     * bias scores reside in the range of -100 to 100 with minimum and maximum values corresponding to
     * a full ban or exclusive selection of a token, respectively. The exact behavior of a given bias
     * score varies by model.
     */
    logit_bias?: Record<string, number>;
    /**
     * An identifier for the caller or end user of the operation. This may be used for tracking
     * or rate-limiting purposes.
     */
    user?: string;
    /**
     * The number of completions choices that should be generated per provided prompt as part of an
     * overall completions response.
     * Because this setting can generate many completions, it may quickly consume your token quota.
     * Use carefully and ensure reasonable settings for max_tokens and stop.
     */
    n?: number;
    /**
     * A value that controls the emission of log probabilities for the provided number of most likely
     * tokens within a completions response.
     */
    logprobs?: number;
    /**
     * A value specifying whether completions responses should include input prompts as prefixes to
     * their generated output.
     */
    echo?: boolean;
    /** A collection of textual sequences that will end completions generation. */
    stop?: string[];
    /**
     * A value that influences the probability of generated tokens appearing based on their existing
     * presence in generated text.
     * Positive values will make tokens less likely to appear when they already exist and increase the
     * model's likelihood to output new topics.
     */
    presence_penalty?: number;
    /**
     * A value that influences the probability of generated tokens appearing based on their cumulative
     * frequency in generated text.
     * Positive values will make tokens less likely to appear as their frequency increases and
     * decrease the likelihood of the model repeating the same statements verbatim.
     */
    frequency_penalty?: number;
    /**
     * A value that controls how many completions will be internally generated prior to response
     * formulation.
     * When used together with n, best_of controls the number of candidate completions and must be
     * greater than n.
     * Because this setting can generate many completions, it may quickly consume your token quota.
     * Use carefully and ensure reasonable settings for max_tokens and stop.
     */
    best_of?: number;
    /** A value indicating whether chat completions should be streamed for this request. */
    stream?: boolean;
    /**
     * The model name to provide as part of this completions request.
     * Not applicable to Azure OpenAI, where deployment information should be included in the Azure
     * resource URI that's connected to.
     */
    model?: string;
}

/**
 * Representation of the response data from a completions request.
 * Completions support a wide variety of tasks and generate text that continues from or "completes"
 * provided prompt data.
 */
declare interface CompletionsOutput {
    /** A unique identifier associated with this completions response. */
    id: string;
    /**
     * The first timestamp associated with generation activity for this completions response,
     * represented as seconds since the beginning of the Unix epoch of 00:00 on 1 Jan 1970.
     */
    created: number;
    /**
     * The collection of completions choices associated with this completions response.
     * Generally, `n` choices are generated per provided prompt with a default value of 1.
     * Token limits and other settings may limit the number of choices generated.
     */
    choices?: Array<ChoiceOutput>;
    /** Usage information for tokens processed and generated as part of this completions operation. */
    usage: CompletionsUsageOutput;
}

export declare type CompletionsStream = AsyncIterable<Omit<DeploymentCompletionsOptionsCompletions, "usage">>;

/**
 * Representation of the token counts processed for a completions request.
 * Counts consider all tokens across prompts, choices, choice alternates, best_of generations, and
 * other consumers.
 */
export declare interface CompletionsUsage {
    /** The number of tokens generated across all completions emissions. */
    completionTokens: number;
    /** The number of tokens in the provided prompts for the completions request. */
    promptTokens: number;
    /** The total number of tokens processed for the completions request and response. */
    totalTokens: number;
}

/**
 * Representation of the token counts processed for a completions request.
 * Counts consider all tokens across prompts, choices, choice alternates, best_of generations, and
 * other consumers.
 */
declare interface CompletionsUsageOutput {
    /** The number of tokens generated across all completions emissions. */
    completion_tokens: number;
    /** The number of tokens in the provided prompts for the completions request. */
    prompt_tokens: number;
    /** The total number of tokens processed for the completions request and response. */
    total_tokens: number;
}

/** */
export declare interface DeploymentChatCompletionsOptionsChatCompletions {
    /** A unique identifier associated with this chat completions response. */
    id: string;
    /**
     * The first timestamp associated with generation activity for this completions response,
     * represented as seconds since the beginning of the Unix epoch of 00:00 on 1 Jan 1970.
     */
    created: number;
    /**
     * The collection of completions choices associated with this completions response.
     * Generally, `n` choices are generated per provided prompt with a default value of 1.
     * Token limits and other settings may limit the number of choices generated.
     */
    choices?: ChatChoice[];
    /** Usage information for tokens processed and generated as part of this completions operation. */
    usage: CompletionsUsage;
}

/** */
export declare interface DeploymentCompletionsOptionsCompletions {
    /** A unique identifier associated with this completions response. */
    id: string;
    /**
     * The first timestamp associated with generation activity for this completions response,
     * represented as seconds since the beginning of the Unix epoch of 00:00 on 1 Jan 1970.
     */
    created: number;
    /**
     * The collection of completions choices associated with this completions response.
     * Generally, `n` choices are generated per provided prompt with a default value of 1.
     * Token limits and other settings may limit the number of choices generated.
     */
    choices?: Choice[];
    /** Usage information for tokens processed and generated as part of this completions operation. */
    usage: CompletionsUsage;
}

/** */
export declare interface DeploymentEmbeddingsOptionsEmbeddings {
    /** Embedding values for the prompts submitted in the request. */
    data: EmbeddingItem[];
    /** Usage counts for tokens input using the embeddings API. */
    usage: EmbeddingsUsage;
}

/** Representation of a single embeddings relatedness comparison. */
export declare interface EmbeddingItem {
    /**
     * List of embeddings value for the input prompt. These represent a measurement of the
     * vector-based relatedness of the provided input.
     */
    embedding: number[];
    /** Index of the prompt to which the EmbeddingItem corresponds. */
    index: number;
}

/** Representation of a single embeddings relatedness comparison. */
declare interface EmbeddingItemOutput {
    /**
     * List of embeddings value for the input prompt. These represent a measurement of the
     * vector-based relatedness of the provided input.
     */
    embedding: number[];
    /** Index of the prompt to which the EmbeddingItem corresponds. */
    index: number;
}

/** */
export declare interface EmbeddingsOptions {
    /**
     * An identifier for the caller or end user of the operation. This may be used for tracking
     * or rate-limiting purposes.
     */
    user?: string;
    /**
     * The model name to provide as part of this embeddings request.
     * Not applicable to Azure OpenAI, where deployment information should be included in the Azure
     * resource URI that's connected to.
     */
    model?: string;
    /**
     * Input text to get embeddings for, encoded as a string.
     * To get embeddings for multiple inputs in a single request, pass an array of strings.
     * Each input must not exceed 2048 tokens in length.
     *
     * Unless you are embedding code, we suggest replacing newlines (\n) in your input with a single space,
     * as we have observed inferior results when newlines are present.
     */
    input: string | string[];
}

/**
 * The configuration information for an embeddings request.
 * Embeddings measure the relatedness of text strings and are commonly used for search, clustering,
 * recommendations, and other similar scenarios.
 */
declare interface EmbeddingsOptions_2 {
    /**
     * An identifier for the caller or end user of the operation. This may be used for tracking
     * or rate-limiting purposes.
     */
    user?: string;
    /**
     * The model name to provide as part of this embeddings request.
     * Not applicable to Azure OpenAI, where deployment information should be included in the Azure
     * resource URI that's connected to.
     */
    model?: string;
    /**
     * Input text to get embeddings for, encoded as a string.
     * To get embeddings for multiple inputs in a single request, pass an array of strings.
     * Each input must not exceed 2048 tokens in length.
     *
     * Unless you are embedding code, we suggest replacing newlines (\n) in your input with a single space,
     * as we have observed inferior results when newlines are present.
     */
    input: string | string[];
}

/**
 * Representation of the response data from an embeddings request.
 * Embeddings measure the relatedness of text strings and are commonly used for search, clustering,
 * recommendations, and other similar scenarios.
 */
declare interface EmbeddingsOutput {
    /** Embedding values for the prompts submitted in the request. */
    data: Array<EmbeddingItemOutput>;
    /** Usage counts for tokens input using the embeddings API. */
    usage: EmbeddingsUsageOutput;
}

/** Measurement of the amount of tokens used in this request and response. */
export declare interface EmbeddingsUsage {
    /** Number of tokens sent in the original request. */
    promptTokens: number;
    /** Total number of tokens transacted in this request/response. */
    totalTokens: number;
}

/** Measurement of the amount of tokens used in this request and response. */
declare interface EmbeddingsUsageOutput {
    /** Number of tokens sent in the original request. */
    prompt_tokens: number;
    /** Total number of tokens transacted in this request/response. */
    total_tokens: number;
}

declare interface GetChatCompletions {
    /**
     * Gets chat completions for the provided chat messages.
     * Completions support a wide variety of tasks and generate text that continues from or "completes"
     * provided prompt data.
     */
    post(options?: GetChatCompletionsParameters): StreamableMethod<GetChatCompletions200Response | GetChatCompletionsDefaultResponse>;
}

/**
 * Gets chat completions for the provided chat messages.
 * Completions support a wide variety of tasks and generate text that continues from or "completes"
 * provided prompt data.
 */
export declare function getChatCompletions(context: OpenAIContext, messages: ChatMessage[], deploymentId: string, options?: GetChatCompletionsOptions): Promise<DeploymentChatCompletionsOptionsChatCompletions>;

/** The request has succeeded. */
declare interface GetChatCompletions200Response extends HttpResponse {
    status: "200";
    body: ChatCompletionsOutput;
}

declare interface GetChatCompletionsBodyParam {
    body?: ChatCompletionsOptions_2;
}

declare interface GetChatCompletionsDefaultHeaders {
    /** String error code indicating what went wrong. */
    "x-ms-error-code"?: string;
}

declare interface GetChatCompletionsDefaultResponse extends HttpResponse {
    status: string;
    body: ErrorResponse;
    headers: RawHttpHeaders & GetChatCompletionsDefaultHeaders;
}

export declare interface GetChatCompletionsOptions extends RequestOptions {
    /** The maximum number of tokens to generate. */
    maxTokens?: number;
    /**
     * The sampling temperature to use that controls the apparent creativity of generated completions.
     * Higher values will make output more random while lower values will make results more focused
     * and deterministic.
     * It is not recommended to modify temperature and top_p for the same completions request as the
     * interaction of these two settings is difficult to predict.
     */
    temperature?: number;
    /**
     * An alternative to sampling with temperature called nucleus sampling. This value causes the
     * model to consider the results of tokens with the provided probability mass. As an example, a
     * value of 0.15 will cause only the tokens comprising the top 15% of probability mass to be
     * considered.
     * It is not recommended to modify temperature and top_p for the same completions request as the
     * interaction of these two settings is difficult to predict.
     */
    topP?: number;
    /**
     * A map between GPT token IDs and bias scores that influences the probability of specific tokens
     * appearing in a completions response. Token IDs are computed via external tokenizer tools, while
     * bias scores reside in the range of -100 to 100 with minimum and maximum values corresponding to
     * a full ban or exclusive selection of a token, respectively. The exact behavior of a given bias
     * score varies by model.
     */
    logitBias?: Record<string, number>;
    /**
     * An identifier for the caller or end user of the operation. This may be used for tracking
     * or rate-limiting purposes.
     */
    user?: string;
    /**
     * The number of completions choices that should be generated per provided prompt as part of an
     * overall completions response.
     * Because this setting can generate many completions, it may quickly consume your token quota.
     * Use carefully and ensure reasonable settings for max_tokens and stop.
     */
    n?: number;
    /** A collection of textual sequences that will end completions generation. */
    stop?: string[];
    /**
     * A value that influences the probability of generated tokens appearing based on their existing
     * presence in generated text.
     * Positive values will make tokens less likely to appear when they already exist and increase the
     * model's likelihood to output new topics.
     */
    presencePenalty?: number;
    /**
     * A value that influences the probability of generated tokens appearing based on their cumulative
     * frequency in generated text.
     * Positive values will make tokens less likely to appear as their frequency increases and
     * decrease the likelihood of the model repeating the same statements verbatim.
     */
    frequencyPenalty?: number;
    /** A value indicating whether chat completions should be streamed for this request. */
    stream?: boolean;
    /**
     * The model name to provide as part of this completions request.
     * Not applicable to Azure OpenAI, where deployment information should be included in the Azure
     * resource URI that's connected to.
     */
    model?: string;
    /** Accept header. */
    accept?: "application/json";
    /** Body parameter Content-Type. Known values are: application/json. */
    content_type?: string;
}

export declare type GetChatCompletionsOptionsNoStream = Omit<GetChatCompletionsOptions, "stream">;

declare type GetChatCompletionsParameters = GetChatCompletionsBodyParam & RequestParameters;

declare interface GetCompletions {
    /**
     * Gets completions for the provided input prompts.
     * Completions support a wide variety of tasks and generate text that continues from or "completes"
     * provided prompt data.
     */
    post(options?: GetCompletionsParameters): StreamableMethod<GetCompletions200Response | GetCompletionsDefaultResponse>;
}

/**
 * Gets completions for the provided input prompts.
 * Completions support a wide variety of tasks and generate text that continues from or "completes"
 * provided prompt data.
 */
export declare function getCompletions(context: OpenAIContext, deploymentId: string, options?: GetCompletionsOptions): Promise<DeploymentCompletionsOptionsCompletions>;

/**
 * Gets completions for the provided input prompts.
 * Completions support a wide variety of tasks and generate text that continues from or "completes"
 * provided prompt data.
 */
export declare function getCompletions(context: OpenAIContext, deploymentId: string, prompt: string | string[], options?: GetCompletionsOptions): Promise<DeploymentCompletionsOptionsCompletions>;

/**
 * Gets completions for the provided input prompts.
 * Completions support a wide variety of tasks and generate text that continues from or "completes"
 * provided prompt data.
 */
export declare function getCompletions(context: OpenAIContext, deploymentId: string, options?: GetCompletionsOptions): Promise<DeploymentCompletionsOptionsCompletions>;

/**
 * Gets completions for the provided input prompts.
 * Completions support a wide variety of tasks and generate text that continues from or "completes"
 * provided prompt data.
 */
export declare function getCompletions(context: OpenAIContext, deploymentId: string, prompt: string | string[], options?: GetCompletionsOptions): Promise<DeploymentCompletionsOptionsCompletions>;

/** The request has succeeded. */
declare interface GetCompletions200Response extends HttpResponse {
    status: "200";
    body: CompletionsOutput;
}

declare interface GetCompletionsBodyParam {
    body?: CompletionsOptions_2;
}

declare interface GetCompletionsDefaultHeaders {
    /** String error code indicating what went wrong. */
    "x-ms-error-code"?: string;
}

declare interface GetCompletionsDefaultResponse extends HttpResponse {
    status: string;
    body: ErrorResponse;
    headers: RawHttpHeaders & GetCompletionsDefaultHeaders;
}

export declare interface GetCompletionsOptions extends RequestOptions {
    /**
     * The prompts to generate completions from. Defaults to a single prompt of <|endoftext|> if not
     * otherwise specified.
     */
    prompt?: string[] | string;
    /** The maximum number of tokens to generate. */
    maxTokens?: number;
    /**
     * The sampling temperature to use that controls the apparent creativity of generated completions.
     * Higher values will make output more random while lower values will make results more focused
     * and deterministic.
     * It is not recommended to modify temperature and top_p for the same completions request as the
     * interaction of these two settings is difficult to predict.
     */
    temperature?: number;
    /**
     * An alternative to sampling with temperature called nucleus sampling. This value causes the
     * model to consider the results of tokens with the provided probability mass. As an example, a
     * value of 0.15 will cause only the tokens comprising the top 15% of probability mass to be
     * considered.
     * It is not recommended to modify temperature and top_p for the same completions request as the
     * interaction of these two settings is difficult to predict.
     */
    topP?: number;
    /**
     * A map between GPT token IDs and bias scores that influences the probability of specific tokens
     * appearing in a completions response. Token IDs are computed via external tokenizer tools, while
     * bias scores reside in the range of -100 to 100 with minimum and maximum values corresponding to
     * a full ban or exclusive selection of a token, respectively. The exact behavior of a given bias
     * score varies by model.
     */
    logitBias?: Record<string, number>;
    /**
     * An identifier for the caller or end user of the operation. This may be used for tracking
     * or rate-limiting purposes.
     */
    user?: string;
    /**
     * The number of completions choices that should be generated per provided prompt as part of an
     * overall completions response.
     * Because this setting can generate many completions, it may quickly consume your token quota.
     * Use carefully and ensure reasonable settings for max_tokens and stop.
     */
    n?: number;
    /**
     * A value that controls the emission of log probabilities for the provided number of most likely
     * tokens within a completions response.
     */
    logprobs?: number;
    /**
     * A value specifying whether completions responses should include input prompts as prefixes to
     * their generated output.
     */
    echo?: boolean;
    /** A collection of textual sequences that will end completions generation. */
    stop?: string[];
    /**
     * A value that influences the probability of generated tokens appearing based on their existing
     * presence in generated text.
     * Positive values will make tokens less likely to appear when they already exist and increase the
     * model's likelihood to output new topics.
     */
    presencePenalty?: number;
    /**
     * A value that influences the probability of generated tokens appearing based on their cumulative
     * frequency in generated text.
     * Positive values will make tokens less likely to appear as their frequency increases and
     * decrease the likelihood of the model repeating the same statements verbatim.
     */
    frequencyPenalty?: number;
    /**
     * A value that controls how many completions will be internally generated prior to response
     * formulation.
     * When used together with n, best_of controls the number of candidate completions and must be
     * greater than n.
     * Because this setting can generate many completions, it may quickly consume your token quota.
     * Use carefully and ensure reasonable settings for max_tokens and stop.
     */
    bestOf?: number;
    /** A value indicating whether chat completions should be streamed for this request. */
    stream?: boolean;
    /**
     * The model name to provide as part of this completions request.
     * Not applicable to Azure OpenAI, where deployment information should be included in the Azure
     * resource URI that's connected to.
     */
    model?: string;
    /** Accept header. */
    accept?: "application/json";
    /** Body parameter Content-Type. Known values are: application/json. */
    content_type?: string;
}

export declare type GetCompletionsOptionsNoStream = Omit<GetCompletionsOptions, "stream">;

declare type GetCompletionsParameters = GetCompletionsBodyParam & RequestParameters;

declare interface GetEmbeddings {
    /** Return the embeddings for a given prompt. */
    post(options?: GetEmbeddingsParameters): StreamableMethod<GetEmbeddings200Response | GetEmbeddingsDefaultResponse>;
}

/** Return the embeddings for a given prompt. */
export declare function getEmbeddings(context: OpenAIContext, input: string | string[], deploymentId: string, options?: GetEmbeddingsOptions): Promise<DeploymentEmbeddingsOptionsEmbeddings>;

/** The request has succeeded. */
declare interface GetEmbeddings200Response extends HttpResponse {
    status: "200";
    body: EmbeddingsOutput;
}

declare interface GetEmbeddingsBodyParam {
    body?: EmbeddingsOptions_2;
}

declare interface GetEmbeddingsDefaultHeaders {
    /** String error code indicating what went wrong. */
    "x-ms-error-code"?: string;
}

declare interface GetEmbeddingsDefaultResponse extends HttpResponse {
    status: string;
    body: ErrorResponse;
    headers: RawHttpHeaders & GetEmbeddingsDefaultHeaders;
}

export declare interface GetEmbeddingsOptions extends RequestOptions {
    /**
     * An identifier for the caller or end user of the operation. This may be used for tracking
     * or rate-limiting purposes.
     */
    user?: string;
    /**
     * The model name to provide as part of this embeddings request.
     * Not applicable to Azure OpenAI, where deployment information should be included in the Azure
     * resource URI that's connected to.
     */
    model?: string;
    /** Accept header. */
    accept?: "application/json";
    /** Body parameter Content-Type. Known values are: application/json. */
    content_type?: string;
}

declare type GetEmbeddingsParameters = GetEmbeddingsBodyParam & RequestParameters;

export declare class OpenAIClient {
    private _client;
    private _isAzure;
    /** Azure OpenAI APIs for completions and search */
    constructor(openAiKey: KeyCredential, options?: ClientOptions);
    constructor(endpoint: string, credential: KeyCredential | TokenCredential, options?: ClientOptions);
    getEmbeddings(deploymentOrModelName: string, input: string | string[], options?: GetEmbeddingsOptions): Promise<DeploymentEmbeddingsOptionsEmbeddings>;
    getChatCompletions(deploymentOrModelName: string, messages: ChatMessage[], options?: GetChatCompletionsOptionsNoStream): Promise<DeploymentChatCompletionsOptionsChatCompletions>;
    getCompletions(deploymentOrModelName: string, prompt: string | string[], options?: GetCompletionsOptionsNoStream): Promise<DeploymentCompletionsOptionsCompletions>;
    getCompletions(deploymentOrModelName: string, options?: GetCompletionsOptionsNoStream): Promise<DeploymentCompletionsOptionsCompletions>;
    getCompletionsStreaming(deploymentOrModelName: string, prompt: string | string[], options?: GetCompletionsOptionsNoStream): Promise<CompletionsStream>;
    getCompletionsStreaming(deploymentOrModelName: string, options?: GetCompletionsOptionsNoStream): Promise<CompletionsStream>;
    getChatCompletionsStreaming(deploymentOrModelName: string, messages: ChatMessage[], options?: GetChatCompletionsOptionsNoStream): Promise<ChatCompletionsStream>;
    private setModel;
}

declare type OpenAIContext = Client & {
    path: Routes;
};

/**
 * The OpenAIKeyCredential class represents an OpenAI key
 * and is used to authenticate into an OpenAI client for
 * an OpenAI endpoint.
 */
export declare class OpenAIKeyCredential implements KeyCredential {
    private _key;
    /**
     * Create an instance of an AzureKeyCredential for use
     * with a service client.
     *
     * @param key - The initial value of the key to use in authentication
     */
    constructor(key: string);
    /**
     * The value of the key to be used in authentication
     */
    get key(): string;
    /**
     * Change the value of the key.
     *
     * Updates will take effect upon the next request after
     * updating the key value.
     *
     * @param newKey - The new key value to be used
     */
    /**
     * Change the value of the key.
     *
     * Updates will take effect upon the next request after
     * updating the key value.
     *
     * @param newKey - The new key value to be used
     */
    update(newKey: string): void;
}

export declare interface RequestOptions {
    requestOptions?: {
        /**
         * Headers to send along with the request
         */
        headers?: RawHttpHeadersInput;
        /**
         * Body to send with the request
         */
        body?: unknown;
        /**
         * Query parameters to send with the request
         */
        queryParameters?: Record<string, unknown>;
        /** Set to true if the request is sent over HTTP instead of HTTPS */
        allowInsecureConnection?: boolean;
        /** Set to true if you want to skip encoding the path parameters */
        skipUrlEncoding?: boolean;
    };
}

declare interface Routes {
    /** Resource for '/deployments/\{deploymentId\}/embeddings' has methods for the following verbs: post */
    (path: "/deployments/{deploymentId}/embeddings", deploymentId: string): GetEmbeddings;
    /** Resource for '/deployments/\{deploymentId\}/completions' has methods for the following verbs: post */
    (path: "/deployments/{deploymentId}/completions", deploymentId: string): GetCompletions;
    /** Resource for '/deployments/\{deploymentId\}/chat/completions' has methods for the following verbs: post */
    (path: "/deployments/{deploymentId}/chat/completions", deploymentId: string): GetChatCompletions;
}

export { }
