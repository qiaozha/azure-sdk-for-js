export declare const testPollingOptions: {
    updateIntervalInMs: number | undefined;
};
//# sourceMappingURL=openai_example.spec.d.ts.map