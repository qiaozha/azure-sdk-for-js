export declare function main(): Promise<void>;
//# sourceMappingURL=chatCompletionsStream.d.ts.map