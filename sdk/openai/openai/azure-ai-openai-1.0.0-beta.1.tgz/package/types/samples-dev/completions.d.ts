export declare function main(): Promise<void>;
//# sourceMappingURL=completions.d.ts.map