export declare function main(): Promise<void>;
//# sourceMappingURL=chatCompletionsInApi.d.ts.map