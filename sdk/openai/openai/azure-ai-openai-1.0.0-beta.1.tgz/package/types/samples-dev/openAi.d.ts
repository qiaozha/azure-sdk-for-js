export declare function main(): Promise<void>;
//# sourceMappingURL=openAi.d.ts.map