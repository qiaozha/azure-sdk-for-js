export declare function main(): Promise<void>;
//# sourceMappingURL=chatCompletions.d.ts.map