export declare function main(): Promise<void>;
//# sourceMappingURL=completionsStream.d.ts.map