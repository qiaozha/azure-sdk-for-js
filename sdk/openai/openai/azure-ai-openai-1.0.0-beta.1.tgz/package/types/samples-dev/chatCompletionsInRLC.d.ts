export declare function main(): Promise<void>;
//# sourceMappingURL=chatCompletionsInRLC.d.ts.map