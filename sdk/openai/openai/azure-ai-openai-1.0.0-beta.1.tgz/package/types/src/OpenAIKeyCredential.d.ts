import { KeyCredential } from "@azure/core-auth";
/**
 * The OpenAIKeyCredential class represents an OpenAI key
 * and is used to authenticate into an OpenAI client for
 * an OpenAI endpoint.
 */
export declare class OpenAIKeyCredential implements KeyCredential {
    private _key;
    /**
     * Create an instance of an AzureKeyCredential for use
     * with a service client.
     *
     * @param key - The initial value of the key to use in authentication
     */
    constructor(key: string);
    /**
     * The value of the key to be used in authentication
     */
    get key(): string;
    /**
     * Change the value of the key.
     *
     * Updates will take effect upon the next request after
     * updating the key value.
     *
     * @param newKey - The new key value to be used
     */
    /**
     * Change the value of the key.
     *
     * Updates will take effect upon the next request after
     * updating the key value.
     *
     * @param newKey - The new key value to be used
     */
    update(newKey: string): void;
}
//# sourceMappingURL=OpenAIKeyCredential.d.ts.map