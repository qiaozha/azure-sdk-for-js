import { StreamableMethod } from "@azure-rest/core-client";
export declare function getSSEs<TResponse, TEvent>(response: StreamableMethod<TResponse>, toEvent: (obj: Record<string, any>) => TEvent): Promise<AsyncIterable<TEvent>>;
//# sourceMappingURL=sse.d.ts.map