import { KeyCredential, TokenCredential } from "@azure/core-auth";
import { ClientOptions } from "../common/interfaces.js";
import { OpenAIContext } from "../rest/index.js";
export { OpenAIContext } from "../rest/index.js";
/** Azure OpenAI APIs for completions and search */
export declare function createOpenAI(endpoint: string, credential: KeyCredential | TokenCredential, options?: ClientOptions): OpenAIContext;
//# sourceMappingURL=OpenAIContext.d.ts.map