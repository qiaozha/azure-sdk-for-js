import { StreamableMethod } from "@azure-rest/core-client";
export declare function getStream<TResponse>(response: StreamableMethod<TResponse>): AsyncIterable<string>;
//# sourceMappingURL=getStream.d.ts.map