import { KeyCredential, TokenCredential } from "@azure/core-auth";
import { ChatMessage, DeploymentChatCompletionsOptionsChatCompletions, DeploymentCompletionsOptionsCompletions, DeploymentEmbeddingsOptionsEmbeddings, GetChatCompletionsOptions, GetCompletionsOptions, GetEmbeddingsOptions } from "./api/index.js";
import { ClientOptions } from "./common/interfaces.js";
export type CompletionsStream = AsyncIterable<Omit<DeploymentCompletionsOptionsCompletions, "usage">>;
export type ChatCompletionsStream = AsyncIterable<Omit<DeploymentChatCompletionsOptionsChatCompletions, "usage">>;
export type GetCompletionsOptionsNoStream = Omit<GetCompletionsOptions, "stream">;
export type GetChatCompletionsOptionsNoStream = Omit<GetChatCompletionsOptions, "stream">;
export declare class OpenAIClient {
    private _client;
    private _isAzure;
    /** Azure OpenAI APIs for completions and search */
    constructor(openAiKey: KeyCredential, options?: ClientOptions);
    constructor(endpoint: string, credential: KeyCredential | TokenCredential, options?: ClientOptions);
    getEmbeddings(deploymentOrModelName: string, input: string | string[], options?: GetEmbeddingsOptions): Promise<DeploymentEmbeddingsOptionsEmbeddings>;
    getChatCompletions(deploymentOrModelName: string, messages: ChatMessage[], options?: GetChatCompletionsOptionsNoStream): Promise<DeploymentChatCompletionsOptionsChatCompletions>;
    getCompletions(deploymentOrModelName: string, prompt: string | string[], options?: GetCompletionsOptionsNoStream): Promise<DeploymentCompletionsOptionsCompletions>;
    getCompletions(deploymentOrModelName: string, options?: GetCompletionsOptionsNoStream): Promise<DeploymentCompletionsOptionsCompletions>;
    getCompletionsStreaming(deploymentOrModelName: string, prompt: string | string[], options?: GetCompletionsOptionsNoStream): Promise<CompletionsStream>;
    getCompletionsStreaming(deploymentOrModelName: string, options?: GetCompletionsOptionsNoStream): Promise<CompletionsStream>;
    getChatCompletionsStreaming(deploymentOrModelName: string, messages: ChatMessage[], options?: GetChatCompletionsOptionsNoStream): Promise<ChatCompletionsStream>;
    private setModel;
}
//# sourceMappingURL=OpenAIClient.d.ts.map